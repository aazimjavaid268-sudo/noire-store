# NOIRÉ storefront starter

A responsive one-page streetwear storefront prototype.

## Run locally
Open `index.html` in a browser. It uses remote Unsplash product imagery and Google Fonts, so internet access is needed for those assets.

## Prototype features
- Responsive home page and category tiles
- Product filters and live search
- Shopping bag drawer with quantity controls and subtotal
- Cart persists in localStorage
- Newsletter UI
- SEO title, description, theme-color

## Not live commerce yet
Checkout is a demo alert. Newsletter isn't connected to a mailing service. Product data is local. Before selling, connect Supabase (product inventory, orders, customer accounts), configure server-side checkout with a payment provider such as Razorpay, and add policies, secrets, shipping/tax rules, and legal/return pages.

## Suggested deploy
Deploy this static prototype to Vercel or Netlify. For Google Search, use a real domain, add Search Console, verify ownership, submit a sitemap, and ensure the deployed pages are crawlable. Search indexing isn't immediate or guaranteed.
