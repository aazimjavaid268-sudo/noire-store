# Antigravity build prompt — NOIRÉ


You are a senior full-stack engineer. Turn this NOIRÉ streetwear storefront prototype into a production-ready Indian ecommerce store.


## Existing direction
- Premium streetwear brand NOIRÉ
- Minimal black/off-white/grey palette with lime accent
- Editorial, clean, responsive design
- Existing `index.html` is the visual prototype; preserve its design intent, improve it where needed

## Required stack
- Next.js App Router + TypeScript
- Tailwind CSS
- Supabase: PostgreSQL, Auth, Storage
- Razorpay payments (test mode first; never expose secret keys client-side)
- Deploy to Vercel

## Build requirements
1. Product listing, product detail pages, categories, search, sorting, size/color selection, inventory validation.
2. Cart persisted for guests and synced for authenticated users where possible.
3. Secure checkout: create order server-side, create Razorpay order server-side, verify signature server-side, update order/payment status using trusted webhook; never trust client-submitted totals.
4. Supabase Auth customer accounts and order history.
5. Admin-only dashboard protected by server-side authorization for product CRUD, inventory, image uploads, order management. Use role claims or a secure admin table; do not rely on hiding UI.
6. Newsletter signup stored in Supabase with validation and duplicate handling.
7. Add loading, empty, error, success states; accessibility, keyboard navigation, responsive layouts.
8. SEO: unique metadata, OpenGraph, canonical, robots.txt, sitemap.xml, structured Product data where appropriate; avoid indexing empty/duplicate pages.
9. Add shipping, return/refund, privacy, terms, contact pages and clearly label demo content until verified.
10. Create `.env.example`; document every secret. Never commit `.env`.
11. Create Supabase SQL migrations and secure RLS policies for products (public read), orders (user reads own), profiles (user reads/updates own), newsletter (public insert only with validation), and admin operations (restricted). Keep service-role key server-only.
12. Add a clear setup README with Supabase project setup, migration commands, storage bucket/policies, Razorpay test setup, local run and Vercel deploy.

## Work style
Inspect the prototype first, then implement. Do not stop at a plan or mockup. Run lint/build, fix all errors, and report what is complete versus what still needs credentials or manual configuration. Do not invent real products, prices, legal policies, or payment credentials. Use clearly marked sample products until owner replaces them.
